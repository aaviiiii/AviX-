import { Button } from "@/components/ui/button";
import { Bot, Code, Brain, Smartphone, BarChart, Cloud } from "lucide-react";
import type { BusinessInfo } from "@shared/schema";

interface BusinessSidebarProps {
  businessInfo?: BusinessInfo;
}

export default function BusinessSidebar({ businessInfo }: BusinessSidebarProps) {
  const serviceIcons = {
    "Website Development": Code,
    "AI Solutions": Brain,
    "App Development": Smartphone,
    "CRM Systems": BarChart,
    "Cloud Services": Cloud,
  };

  const handleScheduleDemo = () => {
    // This would typically trigger a demo modal or scroll to demo section
    console.log("Schedule demo clicked");
  };

  return (
    <div className="w-full bg-gradient-to-br from-[hsl(218,91%,60%)] to-[hsl(262,83%,58%)] text-white p-6 flex flex-col">
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-3">
            <Bot className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold">{businessInfo?.name || "Business Solutions"}</h1>
            <p className="text-blue-100 text-sm">AI Business Assistant</p>
          </div>
        </div>
        
        <div className="flex items-center text-green-300 text-sm mb-6">
          <div className="w-2 h-2 bg-green-300 rounded-full mr-2 animate-pulse"></div>
          <span>24/7 Available • Online Now</span>
        </div>
      </div>

      <div className="space-y-6 flex-1">
        <div>
          <h3 className="font-semibold mb-3 text-blue-100">Our Services</h3>
          <ul className="space-y-2 text-sm text-blue-50">
            {businessInfo?.services?.map((service, index) => {
              const IconComponent = serviceIcons[service as keyof typeof serviceIcons] || Code;
              return (
                <li key={index} className="flex items-center">
                  <IconComponent className="h-4 w-4 mr-2 flex-shrink-0" />
                  {service}
                </li>
              );
            })}
          </ul>
        </div>

        <div className="bg-white bg-opacity-10 rounded-lg p-4">
          <h4 className="font-semibold mb-2">Quick Demo</h4>
          <p className="text-sm text-blue-100 mb-3">See our solutions in action</p>
          <Button
            onClick={handleScheduleDemo}
            className="w-full bg-white text-primary hover:bg-gray-100 font-medium"
          >
            Schedule Free Demo
          </Button>
        </div>
      </div>

      <div className="mt-auto">
        <div className="text-xs text-blue-200">
          <p>Languages: English • हिंदी</p>
          <p className="mt-1">Response time: &lt; 30 seconds</p>
        </div>
      </div>
    </div>
  );
}
