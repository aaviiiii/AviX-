import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import MessageBubble from "./message-bubble";
import ContactModal from "./contact-modal";
import DemoModal from "./demo-modal";
import { useChat } from "@/hooks/use-chat";
import { detectLanguage } from "@/lib/chat-utils";
import type { BusinessInfo, ChatMessage } from "@shared/schema";
import { Bot, Info, Send, Paperclip } from "lucide-react";

interface ChatInterfaceProps {
  sessionId: string;
  businessInfo?: BusinessInfo;
  onShowBusinessInfo: () => void;
}

export default function ChatInterface({ sessionId, businessInfo, onShowBusinessInfo }: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [currentLanguage, setCurrentLanguage] = useState("en");
  const [showContactModal, setShowContactModal] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  const { data: messages = [] } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/messages", sessionId],
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: { content: string; sender: string; language: string; sessionId: string }) => {
      const res = await apiRequest("POST", "/api/chat/messages", messageData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", sessionId] });
    },
  });

  const generateResponseMutation = useMutation({
    mutationFn: async (data: { message: string; language: string; sessionId: string }) => {
      const res = await apiRequest("POST", "/api/chat/generate-response", data);
      return res.json();
    },
    onSuccess: () => {
      setIsTyping(false);
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", sessionId] });
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Send welcome message on initial load
  useEffect(() => {
    if (messages.length === 0 && businessInfo) {
      const welcomeMessage = currentLanguage === 'hi' 
        ? `नमस्ते! ${businessInfo.name} में आपका स्वागत है। मैं आपकी 24/7 सहायता के लिए यहाँ हूँ! आज मैं आपकी कैसे सहायता कर सकता हूँ? 🙏`
        : `Namaste! Welcome to ${businessInfo.name}. I'm here to help you 24/7! How can I assist you today? 🙏`;
      
      sendMessageMutation.mutate({
        content: welcomeMessage,
        sender: 'assistant',
        language: currentLanguage,
        sessionId
      });
    }
  }, [businessInfo, messages.length]);

  const handleSendMessage = async () => {
    if (!message.trim()) return;

    const detectedLanguage = detectLanguage(message);
    setCurrentLanguage(detectedLanguage);

    // Send user message
    await sendMessageMutation.mutateAsync({
      content: message,
      sender: 'user',
      language: detectedLanguage,
      sessionId
    });

    const userMessage = message;
    setMessage("");
    setIsTyping(true);

    // Generate assistant response
    setTimeout(() => {
      generateResponseMutation.mutate({
        message: userMessage,
        language: detectedLanguage,
        sessionId
      });
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleQuickReply = (quickMessage: string) => {
    setMessage(quickMessage);
    setTimeout(() => handleSendMessage(), 100);
  };

  const toggleLanguage = () => {
    setCurrentLanguage(prev => prev === 'en' ? 'hi' : 'en');
  };

  const quickReplies = currentLanguage === 'hi' 
    ? ["आपकी कीमतें क्या हैं?", "डेमो शेड्यूल करें", "सेल्स टीम से संपर्क करें"]
    : ["What are your prices?", "Schedule a demo", "Contact sales team"];

  return (
    <div className="flex flex-col h-full">
      {/* Chat Header */}
      <div className="bg-primary text-primary-foreground px-4 py-3 flex items-center justify-between shadow-md">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-3">
            <Bot className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-semibold">{businessInfo?.name || "Business"} Assistant</h2>
            <div className="flex items-center text-xs text-blue-100">
              <div className="w-2 h-2 bg-green-300 rounded-full mr-1 animate-pulse"></div>
              <span>Online • Typically replies instantly</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleLanguage}
            className="bg-white bg-opacity-20 hover:bg-opacity-30 text-xs font-medium"
          >
            {currentLanguage === 'en' ? 'EN | हि' : 'हि | EN'}
          </Button>
          <Button variant="ghost" size="sm" className="lg:hidden" onClick={onShowBusinessInfo}>
            <Info className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
        {messages.map((msg) => (
          <MessageBubble 
            key={msg.id} 
            message={msg}
            onContactClick={() => setShowContactModal(true)}
            onDemoClick={() => setShowDemoModal(true)}
          />
        ))}
        
        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex items-start animate-fade-in">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center mr-3 flex-shrink-0 mt-1">
              <Bot className="h-4 w-4 text-white" />
            </div>
            <div className="bg-white rounded-2xl rounded-tl-md px-4 py-3 shadow-sm">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full typing-indicator"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full typing-indicator" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full typing-indicator" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="bg-white border-t border-gray-200 p-4">
        <div className="flex items-end space-x-3">
          <div className="flex-1">
            <div className="bg-gray-100 rounded-2xl px-4 py-3 flex items-center">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={currentLanguage === 'hi' ? "अपना संदेश यहाँ लिखें..." : "Type your message... (English or Hindi)"}
                className="flex-1 bg-transparent border-0 outline-0 focus:ring-0 focus-visible:ring-0 shadow-none"
              />
              <Button variant="ghost" size="sm" className="ml-2 text-gray-400 hover:text-gray-600 p-0">
                <Paperclip className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={!message.trim() || sendMessageMutation.isPending}
            className="bg-primary hover:bg-primary/90 text-white w-12 h-12 rounded-full shadow-lg"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Quick Replies */}
        <div className="mt-3 flex flex-wrap gap-2">
          {quickReplies.map((reply, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              onClick={() => handleQuickReply(reply)}
              className="bg-gray-100 border-gray-200 text-gray-600 hover:bg-gray-200 rounded-full text-sm"
            >
              {reply}
            </Button>
          ))}
        </div>
      </div>

      {/* Modals */}
      <ContactModal 
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
        language={currentLanguage}
      />
      
      <DemoModal
        isOpen={showDemoModal}
        onClose={() => setShowDemoModal(false)}
        onContactNeeded={() => {
          setShowDemoModal(false);
          setShowContactModal(true);
        }}
        language={currentLanguage}
      />
    </div>
  );
}
