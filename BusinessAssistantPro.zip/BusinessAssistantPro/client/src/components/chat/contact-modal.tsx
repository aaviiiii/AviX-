import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { insertLeadSchema } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { UserPlus } from "lucide-react";

const formSchema = insertLeadSchema.extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().min(10, "Please enter a valid phone number"),
});

type FormData = z.infer<typeof formSchema>;

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: string;
}

export default function ContactModal({ isOpen, onClose, language }: ContactModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isHindi = language === 'hi';

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      service: "",
      message: "",
    },
  });

  const createLeadMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest("POST", "/api/leads", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: isHindi ? "सफल!" : "Success!",
        description: isHindi 
          ? "आपकी जानकारी सफलतापूर्वक भेजी गई है। हमारी टीम 2 घंटे के भीतर संपर्क करेगी।"
          : "Your details have been submitted successfully. Our team will contact you within 2 hours.",
      });
      reset();
      onClose();
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
    },
    onError: () => {
      toast({
        title: isHindi ? "त्रुटि!" : "Error!",
        description: isHindi 
          ? "कुछ गलत हुआ है। कृपया पुनः प्रयास करें।"
          : "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    createLeadMutation.mutate(data);
  };

  const services = [
    { value: "website", label: isHindi ? "वेबसाइट विकास" : "Website Development" },
    { value: "ai", label: isHindi ? "AI समाधान" : "AI Solutions" },
    { value: "app", label: isHindi ? "ऐप विकास" : "App Development" },
    { value: "crm", label: isHindi ? "CRM सिस्टम" : "CRM Systems" },
    { value: "other", label: isHindi ? "अन्य सेवाएं" : "Other Services" },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader className="text-center space-y-4">
          <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto">
            <UserPlus className="h-8 w-8 text-primary" />
          </div>
          <div>
            <DialogTitle className="text-xl font-bold text-gray-900">
              {isHindi ? "आइए जुड़ते हैं!" : "Let's Connect!"}
            </DialogTitle>
            <p className="text-gray-600 mt-2">
              {isHindi 
                ? "अपनी जानकारी साझा करें ताकि हमारी टीम आपकी बेहतर सहायता कर सके"
                : "Share your details so our team can help you better"}
            </p>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              {isHindi ? "पूरा नाम *" : "Full Name *"}
            </Label>
            <Input
              {...register("name")}
              placeholder={isHindi ? "अपना पूरा नाम दर्ज करें" : "Enter your full name"}
              className="w-full"
            />
            {errors.name && (
              <p className="text-sm text-red-600 mt-1">{errors.name.message}</p>
            )}
          </div>

          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              {isHindi ? "फोन नंबर *" : "Phone Number *"}
            </Label>
            <Input
              {...register("phone")}
              type="tel"
              placeholder="+91 XXXXX XXXXX"
              className="w-full"
            />
            {errors.phone && (
              <p className="text-sm text-red-600 mt-1">{errors.phone.message}</p>
            )}
          </div>

          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              {isHindi ? "ईमेल (वैकल्पिक)" : "Email (Optional)"}
            </Label>
            <Input
              {...register("email")}
              type="email"
              placeholder="your.email@example.com"
              className="w-full"
            />
          </div>

          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              {isHindi ? "हम आपकी कैसे सहायता कर सकते हैं?" : "How can we help?"}
            </Label>
            <Select onValueChange={(value) => setValue("service", value)}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder={isHindi ? "एक सेवा चुनें" : "Select a service"} />
              </SelectTrigger>
              <SelectContent>
                {services.map((service) => (
                  <SelectItem key={service.value} value={service.value}>
                    {service.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex space-x-3 mt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              {isHindi ? "बाद में" : "Maybe Later"}
            </Button>
            <Button
              type="submit"
              disabled={createLeadMutation.isPending}
              className="flex-1 bg-primary hover:bg-primary/90"
            >
              {createLeadMutation.isPending 
                ? (isHindi ? "भेजा जा रहा है..." : "Connecting...")
                : (isHindi ? "अभी जुड़ें" : "Connect Now")
              }
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
