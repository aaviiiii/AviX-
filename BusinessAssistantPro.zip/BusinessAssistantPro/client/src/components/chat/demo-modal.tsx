import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Calendar, Check } from "lucide-react";

interface DemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onContactNeeded: () => void;
  language: string;
}

export default function DemoModal({ isOpen, onClose, onContactNeeded, language }: DemoModalProps) {
  const [selectedTime, setSelectedTime] = useState<string>("");
  const isHindi = language === 'hi';

  const handleBookDemo = () => {
    onContactNeeded();
  };

  const demoFeatures = isHindi ? [
    "लाइव प्रोडक्ट प्रदर्शन",
    "कस्टम समाधान चर्चा", 
    "मूल्य निर्धारण परामर्श",
    "प्रश्न-उत्तर सत्र"
  ] : [
    "Live product demonstration",
    "Custom solution discussion",
    "Pricing consultation",
    "Q&A session"
  ];

  const timeSlots = [
    { value: "today", label: isHindi ? "आज" : "Today", subtitle: isHindi ? "उपलब्ध स्लॉट" : "Available slots" },
    { value: "tomorrow", label: isHindi ? "कल" : "Tomorrow", subtitle: isHindi ? "कई स्लॉट" : "Multiple slots" }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader className="text-center space-y-4">
          <div className="w-16 h-16 bg-green-500 bg-opacity-10 rounded-full flex items-center justify-center mx-auto">
            <Calendar className="h-8 w-8 text-green-600" />
          </div>
          <div>
            <DialogTitle className="text-xl font-bold text-gray-900">
              {isHindi ? "मुफ्त डेमो शेड्यूल करें" : "Schedule Free Demo"}
            </DialogTitle>
            <p className="text-gray-600 mt-2">
              {isHindi 
                ? "हमारे समाधान को क्रिया में देखें - बिल्कुल मुफ्त!"
                : "See our solutions in action - completely free!"}
            </p>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-900 mb-2">
              {isHindi ? "इसमें शामिल है:" : "What's Included:"}
            </h4>
            <ul className="text-sm text-gray-600 space-y-1">
              {demoFeatures.map((feature, index) => (
                <li key={index} className="flex items-center">
                  <Check className="h-4 w-4 text-green-600 mr-2 flex-shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {timeSlots.map((slot) => (
              <Button
                key={slot.value}
                variant={selectedTime === slot.value ? "default" : "outline"}
                onClick={() => setSelectedTime(slot.value)}
                className={`p-3 h-auto flex flex-col items-center justify-center ${
                  selectedTime === slot.value 
                    ? "bg-primary text-white" 
                    : "border-2 border-gray-200 text-gray-700 hover:border-primary hover:text-primary"
                }`}
              >
                <div className="text-sm font-medium">{slot.label}</div>
                <div className="text-xs opacity-75">{slot.subtitle}</div>
              </Button>
            ))}
          </div>

          <div className="flex space-x-3 mt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              {isHindi ? "अभी नहीं" : "Not Now"}
            </Button>
            <Button
              onClick={handleBookDemo}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
            >
              {isHindi ? "डेमो बुक करें" : "Book Demo"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
