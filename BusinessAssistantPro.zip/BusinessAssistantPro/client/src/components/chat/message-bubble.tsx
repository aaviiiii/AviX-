import { Button } from "@/components/ui/button";
import { Bot, Play, Tag, Phone } from "lucide-react";
import type { ChatMessage } from "@shared/schema";

interface MessageBubbleProps {
  message: ChatMessage;
  onContactClick?: () => void;
  onDemoClick?: () => void;
}

export default function MessageBubble({ message, onContactClick, onDemoClick }: MessageBubbleProps) {
  const isUser = message.sender === 'user';
  const shouldShowActions = !isUser && (
    message.content.includes('demo') || 
    message.content.includes('contact') || 
    message.content.includes('pricing') ||
    message.content.includes('डेमो') ||
    message.content.includes('संपर्क') ||
    message.content.includes('कीमत')
  );

  if (isUser) {
    return (
      <div className="flex items-end justify-end animate-slide-up">
        <div className="chat-bubble-user">
          <p dangerouslySetInnerHTML={{ __html: message.content }} />
          <div className="text-xs text-blue-100 mt-1">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start animate-fade-in">
      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center mr-3 flex-shrink-0 mt-1">
        <Bot className="h-4 w-4 text-white" />
      </div>
      <div className="space-y-3">
        <div className="chat-bubble-assistant">
          <p dangerouslySetInnerHTML={{ __html: message.content }} />
          <div className="text-xs text-gray-500 mt-1">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
        
        {shouldShowActions && (
          <div className="space-y-2">
            <Button
              onClick={onDemoClick}
              className="bg-primary hover:bg-primary/90 text-white rounded-full text-sm font-medium flex items-center"
              size="sm"
            >
              <Play className="h-4 w-4 mr-2" />
              {message.language === 'hi' ? 'डेमो का अनुरोध करें' : 'Request Demo'}
            </Button>
            <Button
              onClick={onContactClick}
              variant="outline"
              className="bg-white border-gray-200 text-gray-700 hover:bg-gray-50 rounded-full text-sm font-medium flex items-center"
              size="sm"
            >
              <Phone className="h-4 w-4 mr-2" />
              {message.language === 'hi' ? 'टीम से संपर्क करें' : 'Contact Team'}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
