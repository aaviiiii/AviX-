import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Bot, Code, Brain, Smartphone, BarChart, X } from "lucide-react";
import type { BusinessInfo } from "@shared/schema";

interface MobileBusinessInfoProps {
  businessInfo?: BusinessInfo;
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileBusinessInfo({ businessInfo, isOpen, onClose }: MobileBusinessInfoProps) {
  const serviceInfo = [
    { name: "Web Dev", icon: Code },
    { name: "AI Solutions", icon: Brain },
    { name: "App Dev", icon: Smartphone },
    { name: "CRM", icon: BarChart },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm mx-auto">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-lg font-bold text-gray-900">
            Business Information
          </DialogTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </DialogHeader>

        <div className="space-y-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-3">
              <Bot className="h-8 w-8 text-primary" />
            </div>
            <h4 className="font-semibold text-gray-900">{businessInfo?.name || "Business Solutions"}</h4>
            <p className="text-gray-600 text-sm">Professional AI Assistant</p>
          </div>

          <div>
            <h5 className="font-semibold text-gray-900 mb-3">Our Services</h5>
            <div className="grid grid-cols-2 gap-3">
              {serviceInfo.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <div key={index} className="text-center p-3 bg-gray-50 rounded-lg">
                    <IconComponent className="h-6 w-6 text-primary mx-auto mb-2" />
                    <div className="text-sm font-medium">{service.name}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-primary bg-opacity-10 rounded-lg p-4 text-center">
            <h5 className="font-semibold text-primary mb-2">24/7 Support Available</h5>
            <p className="text-sm text-gray-600">Languages: English • हिंदी</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
