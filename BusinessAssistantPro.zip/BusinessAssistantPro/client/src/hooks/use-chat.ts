import { useState, useCallback } from "react";
import { detectLanguage } from "@/lib/chat-utils";

export interface ChatState {
  sessionId: string;
  currentLanguage: string;
  isTyping: boolean;
  messages: any[];
}

export function useChat(initialSessionId: string) {
  const [sessionId] = useState(initialSessionId);
  const [currentLanguage, setCurrentLanguage] = useState("en");
  const [isTyping, setIsTyping] = useState(false);

  const updateLanguage = useCallback((message: string) => {
    const detectedLanguage = detectLanguage(message);
    setCurrentLanguage(detectedLanguage);
    return detectedLanguage;
  }, []);

  const toggleLanguage = useCallback(() => {
    setCurrentLanguage(prev => prev === "en" ? "hi" : "en");
  }, []);

  const startTyping = useCallback(() => {
    setIsTyping(true);
  }, []);

  const stopTyping = useCallback(() => {
    setIsTyping(false);
  }, []);

  return {
    sessionId,
    currentLanguage,
    isTyping,
    updateLanguage,
    toggleLanguage,
    startTyping,
    stopTyping,
  };
}
