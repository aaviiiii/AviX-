export function detectLanguage(text: string): string {
  // Simple language detection based on Hindi Unicode ranges and common Hindi words
  const hindiWords = ['नमस्ते', 'धन्यवाद', 'कैसे', 'क्या', 'मदद', 'जानकारी', 'हैलो', 'सेवा', 'कीमत', 'दाम', 'डेमो', 'संपर्क', 'टीम'];
  const hindiUnicodeRange = /[\u0900-\u097F]/;
  
  // Check for Hindi words or Unicode characters
  const hasHindiWords = hindiWords.some(word => text.includes(word));
  const hasHindiChars = hindiUnicodeRange.test(text);
  
  return (hasHindiWords || hasHindiChars) ? 'hi' : 'en';
}

export function getLanguageSpecificText(language: string, englishText: string, hindiText: string): string {
  return language === 'hi' ? hindiText : englishText;
}

export function formatTimestamp(timestamp: Date | string): string {
  const date = new Date(timestamp);
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Common response templates for different scenarios
export const responseTemplates = {
  welcome: {
    en: "Namaste! Welcome to {businessName}. I'm here to help you 24/7! How can I assist you today? 🙏",
    hi: "नमस्ते! {businessName} में आपका स्वागत है। मैं आपकी 24/7 सहायता के लिए यहाँ हूँ! आज मैं आपकी कैसे सहायता कर सकता हूँ? 🙏"
  },
  pricing: {
    en: "Our pricing is very competitive! Here's a quick overview:<br><br>📱 Website Development: ₹25,000+<br>🤖 AI Solutions: ₹40,000+<br>📱 App Development: ₹50,000+<br>📊 CRM Systems: ₹30,000+<br><br>Would you like detailed pricing for any specific service? 💰",
    hi: "हमारी मूल्य निर्धारण बहुत प्रतिस्पर्धी है! यहाँ एक त्वरित अवलोकन है:<br><br>📱 वेबसाइट विकास: ₹25,000+<br>🤖 AI समाधान: ₹40,000+<br>📱 ऐप विकास: ₹50,000+<br>📊 CRM सिस्टम: ₹30,000+<br><br>क्या आपको किसी विशिष्ट सेवा के लिए विस्तृत मूल्य निर्धारण चाहिए? 💰"
  },
  demo: {
    en: "Great! I'd love to show you our solutions in action. Our demo includes live product walkthrough, custom solution discussion, and pricing consultation.<br><br>Would you like to schedule it for today or tomorrow? It's completely free! 🎯",
    hi: "बेहतरीन! मैं आपको हमारे समाधान व्यावहारिक रूप से दिखाना चाहूंगा। हमारे डेमो में लाइव प्रोडक्ट वॉकथ्रू, कस्टम समाधान चर्चा, और मूल्य निर्धारण परामर्श शामिल है।<br><br>क्या आप इसे आज या कल के लिए शेड्यूल करना चाहेंगे? यह बिल्कुल मुफ्त है! 🎯"
  },
  contact: {
    en: "Perfect! I'll connect you with our expert team right away. They'll be able to provide detailed information and personalized solutions.<br><br>Could you please share your name and contact number? Our team will reach out within 2 hours! 📞",
    hi: "बिल्कुल सही! मैं आपको हमारी विशेषज्ञ टीम से तुरंत जोड़ दूंगा। वे विस्तृत जानकारी और व्यक्तिगत समाधान प्रदान करने में सक्षम होंगे।<br><br>कृपया अपना नाम और संपर्क नंबर साझा करें? हमारी टीम 2 घंटे के भीतर संपर्क करेगी! 📞"
  }
};
