import { useState, useEffect } from "react";
import ChatInterface from "@/components/chat/chat-interface";
import BusinessSidebar from "@/components/chat/business-sidebar";
import MobileBusinessInfo from "@/components/chat/mobile-business-info";
import { useQuery } from "@tanstack/react-query";
import type { BusinessInfo } from "@shared/schema";

export default function ChatPage() {
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const [showMobileInfo, setShowMobileInfo] = useState(false);

  const { data: businessInfo } = useQuery<BusinessInfo>({
    queryKey: ["/api/business-info"],
  });

  return (
    <div className="flex h-screen bg-gray-50 font-inter">
      <div className="flex-1 flex flex-col max-w-md mx-auto bg-white shadow-xl lg:max-w-4xl lg:mx-0 lg:flex-row">
        
        {/* Business Info Sidebar - Desktop Only */}
        <div className="hidden lg:flex lg:w-1/3">
          <BusinessSidebar businessInfo={businessInfo} />
        </div>

        {/* Chat Interface */}
        <div className="flex-1">
          <ChatInterface 
            sessionId={sessionId}
            businessInfo={businessInfo}
            onShowBusinessInfo={() => setShowMobileInfo(true)}
          />
        </div>

        {/* Mobile Business Info Modal */}
        <MobileBusinessInfo 
          businessInfo={businessInfo}
          isOpen={showMobileInfo}
          onClose={() => setShowMobileInfo(false)}
        />
      </div>
    </div>
  );
}
