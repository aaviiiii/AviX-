import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertChatMessageSchema, insertLeadSchema, insertDemoRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get business information
  app.get("/api/business-info", async (req, res) => {
    try {
      const businessInfo = await storage.getBusinessInfo();
      res.json(businessInfo);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch business information" });
    }
  });

  // Get chat messages for a session
  app.get("/api/chat/messages/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getChatMessages(sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // Create a new chat message
  app.post("/api/chat/messages", async (req, res) => {
    try {
      const validatedData = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(validatedData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid message data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create message" });
      }
    }
  });

  // Generate assistant response
  app.post("/api/chat/generate-response", async (req, res) => {
    try {
      const { message, language = 'en', sessionId } = req.body;
      
      // Simple response generation logic
      const response = generateAssistantResponse(message, language);
      
      // Save assistant response
      const assistantMessage = await storage.createChatMessage({
        content: response,
        sender: 'assistant',
        language,
        sessionId
      });
      
      res.json(assistantMessage);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate response" });
    }
  });

  // Create a new lead
  app.post("/api/leads", async (req, res) => {
    try {
      const validatedData = insertLeadSchema.parse(req.body);
      const lead = await storage.createLead(validatedData);
      res.status(201).json(lead);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid lead data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create lead" });
      }
    }
  });

  // Get all leads
  app.get("/api/leads", async (req, res) => {
    try {
      const leads = await storage.getLeads();
      res.json(leads);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch leads" });
    }
  });

  // Create a demo request
  app.post("/api/demo-requests", async (req, res) => {
    try {
      const validatedData = insertDemoRequestSchema.parse(req.body);
      const demoRequest = await storage.createDemoRequest(validatedData);
      res.status(201).json(demoRequest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid demo request data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create demo request" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to generate assistant responses
function generateAssistantResponse(userMessage: string, language: string): string {
  const message = userMessage.toLowerCase();
  
  // Language detection
  const hindiWords = ['नमस्ते', 'धन्यवाद', 'कैसे', 'क्या', 'मदद', 'जानकारी', 'हैलो', 'सेवा'];
  const isHindi = hindiWords.some(word => userMessage.includes(word)) || language === 'hi';
  
  if (message.includes('demo') || message.includes('demonstration')) {
    return isHindi 
      ? `बेहतरीन! मैं आपको हमारे समाधान व्यावहारिक रूप से दिखाना चाहूंगा। हमारे डेमो में लाइव प्रोडक्ट वॉकथ्रू, कस्टम समाधान चर्चा, और मूल्य निर्धारण परामर्श शामिल है।<br><br>क्या आप इसे आज या कल के लिए शेड्यूल करना चाहेंगे? यह बिल्कुल मुफ्त है! 🎯`
      : `Great! I'd love to show you our solutions in action. Our demo includes live product walkthrough, custom solution discussion, and pricing consultation.<br><br>Would you like to schedule it for today or tomorrow? It's completely free! 🎯`;
  }
  
  if (message.includes('price') || message.includes('cost') || message.includes('pricing') || message.includes('दाम') || message.includes('कीमत')) {
    return isHindi
      ? `हमारी मूल्य निर्धारण बहुत प्रतिस्पर्धी है! यहाँ एक त्वरित अवलोकन है:<br><br>📱 वेबसाइट विकास: ₹25,000+<br>🤖 AI समाधान: ₹40,000+<br>📱 ऐप विकास: ₹50,000+<br>📊 CRM सिस्टम: ₹30,000+<br><br>क्या आपको किसी विशिष्ट सेवा के लिए विस्तृत मूल्य निर्धारण चाहिए? 💰`
      : `Our pricing is very competitive! Here's a quick overview:<br><br>📱 Website Development: ₹25,000+<br>🤖 AI Solutions: ₹40,000+<br>📱 App Development: ₹50,000+<br>📊 CRM Systems: ₹30,000+<br><br>Would you like detailed pricing for any specific service? 💰`;
  }
  
  if (message.includes('contact') || message.includes('team') || message.includes('call') || message.includes('संपर्क') || message.includes('टीम')) {
    return isHindi
      ? `बिल्कुल सही! मैं आपको हमारी विशेषज्ञ टीम से तुरंत जोड़ दूंगा। वे विस्तृत जानकारी और व्यक्तिगत समाधान प्रदान करने में सक्षम होंगे।<br><br>कृपया अपना नाम और संपर्क नंबर साझा करें? हमारी टीम 2 घंटे के भीतर संपर्क करेगी! 📞`
      : `Perfect! I'll connect you with our expert team right away. They'll be able to provide detailed information and personalized solutions.<br><br>Could you please share your name and contact number? Our team will reach out within 2 hours! 📞`;
  }
  
  if (isHindi) {
    return `नमस्ते! आपके संदेश के लिए धन्यवाद। हम आपकी सहायता करने के लिए यहाँ हैं।<br><br>हमारी सेवाएं:<br>• वेबसाइट विकास<br>• AI समाधान<br>• ऐप विकास<br>• CRM सिस्टम<br>• क्लाउड सेवाएं<br><br>आपको किस सेवा में रुचि है? 🚀`;
  }
  
  return `Thank you for your message! I'm here to help you with all your technology needs.<br><br>We specialize in modern digital solutions that help businesses grow. Whether you need a website, AI tools, mobile apps, or CRM systems - we've got you covered!<br><br>What specific solution are you looking for today? 🚀`;
}
