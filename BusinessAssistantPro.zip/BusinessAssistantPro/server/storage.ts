import { 
  users, 
  chatMessages, 
  leads, 
  demoRequests, 
  businessInfo,
  type User, 
  type InsertUser,
  type ChatMessage,
  type InsertChatMessage,
  type Lead,
  type InsertLead,
  type DemoRequest,
  type InsertDemoRequest,
  type BusinessInfo,
  type InsertBusinessInfo
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Chat message methods
  getChatMessages(sessionId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Lead methods
  getLeads(): Promise<Lead[]>;
  getLead(id: number): Promise<Lead | undefined>;
  createLead(lead: InsertLead): Promise<Lead>;
  updateLeadStatus(id: number, status: string): Promise<Lead | undefined>;
  
  // Demo request methods
  getDemoRequests(): Promise<DemoRequest[]>;
  createDemoRequest(demoRequest: InsertDemoRequest): Promise<DemoRequest>;
  
  // Business info methods
  getBusinessInfo(): Promise<BusinessInfo | undefined>;
  createOrUpdateBusinessInfo(info: InsertBusinessInfo): Promise<BusinessInfo>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chatMessages: Map<number, ChatMessage>;
  private leads: Map<number, Lead>;
  private demoRequests: Map<number, DemoRequest>;
  private businessInfo: BusinessInfo | undefined;
  private currentUserId: number;
  private currentMessageId: number;
  private currentLeadId: number;
  private currentDemoId: number;

  constructor() {
    this.users = new Map();
    this.chatMessages = new Map();
    this.leads = new Map();
    this.demoRequests = new Map();
    this.currentUserId = 1;
    this.currentMessageId = 1;
    this.currentLeadId = 1;
    this.currentDemoId = 1;
    
    // Initialize with default business info
    this.businessInfo = {
      id: 1,
      name: "TechCorp Solutions",
      description: "Professional AI-powered business solutions provider",
      services: ["Website Development", "AI Solutions", "App Development", "CRM Systems", "Cloud Services"],
      contactInfo: "Available 24/7 • Multiple languages supported"
    };
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getChatMessages(sessionId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(message => message.sessionId === sessionId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentMessageId++;
    const message: ChatMessage = {
      ...insertMessage,
      id,
      timestamp: new Date()
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async getLeads(): Promise<Lead[]> {
    return Array.from(this.leads.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getLead(id: number): Promise<Lead | undefined> {
    return this.leads.get(id);
  }

  async createLead(insertLead: InsertLead): Promise<Lead> {
    const id = this.currentLeadId++;
    const lead: Lead = {
      ...insertLead,
      id,
      status: 'new',
      createdAt: new Date()
    };
    this.leads.set(id, lead);
    return lead;
  }

  async updateLeadStatus(id: number, status: string): Promise<Lead | undefined> {
    const lead = this.leads.get(id);
    if (lead) {
      const updatedLead = { ...lead, status };
      this.leads.set(id, updatedLead);
      return updatedLead;
    }
    return undefined;
  }

  async getDemoRequests(): Promise<DemoRequest[]> {
    return Array.from(this.demoRequests.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createDemoRequest(insertDemo: InsertDemoRequest): Promise<DemoRequest> {
    const id = this.currentDemoId++;
    const demoRequest: DemoRequest = {
      ...insertDemo,
      id,
      status: 'pending',
      createdAt: new Date()
    };
    this.demoRequests.set(id, demoRequest);
    return demoRequest;
  }

  async getBusinessInfo(): Promise<BusinessInfo | undefined> {
    return this.businessInfo;
  }

  async createOrUpdateBusinessInfo(info: InsertBusinessInfo): Promise<BusinessInfo> {
    const businessInfo: BusinessInfo = {
      ...info,
      id: 1
    };
    this.businessInfo = businessInfo;
    return businessInfo;
  }
}

export const storage = new MemStorage();
